<script type="text/javascript">
<!--

function submitPredefinedPrescription(obj){
    var objid = obj.id;
    var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?plugin=CccPredefinedPrescription&function="+objid+"Prescription"

        $( "#CccPrescriptionresult" ).load( url, function() {
            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
        });
}

function checkABCPlus3TCAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;
		
		if(bodyweight>3 && bodyweight<6){
			var doseperunit='60/30';
			var totaldosage='60/30';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>6 && bodyweight<10){
			var doseperunit='60/30';
			var totaldosage='90/45';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>10 && bodyweight<14){
			var doseperunit='60/30';
			var totaldosage='120/60';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunit='60/30';
			var totaldosage='150/75';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunit='60/30';
			var totaldosage='180/90';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25){
			var doseperunit='600/300';
			var totaldosage='600/300';
			var frequency='OD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			}
		});
}
function checkZDVPlus3TCAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;
		if(bodyweight>3 && bodyweight<6){
			var doseperunit='60/30';
			var totaldosage='60/30';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>6 && bodyweight<10){
			var doseperunit='60/30';
			var totaldosage='90/45';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>10 && bodyweight<14){
			var doseperunit='60/30';
			var totaldosage='120/60';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunit='60/30';
			var totaldosage='150/75';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunit='60/30';
			var totaldosage='180/90';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25){
			var doseperunit='300/150';
			var totaldosage='300/150';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			}
		});
}

function checkABCPlus3TCPlusLPVrAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;

		if(bodyweight>3 && bodyweight<10){
			$("#zdv3tclpvr").modal('show');
		}else if(bodyweight>10 && bodyweight<14){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var totaldosageone='60/30';
			var totaldosagetwo='300/75';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var totaldosageone='150/75';
			var totaldosagetwo='200/50';
			var frequencyone='BD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var totaldosageone='180/90';
			var totaldosagetwo='200/50';
			var frequencyone='BD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25 && bodyweight<35){
			var doseperunitone='600/300';
			var doseperunittwo='100/25';
			var totaldosageone='600/300';
			var totaldosagetwo='300/75';
			var frequencyone='OD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			
		}else if(bodyweight>35){
			var doseperunitone='600/300';
			var doseperunittwo='200/50';
			var totaldosageone='600/300';
			var totaldosagetwo='400/100';
			var frequencyone='OD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			}
		});
}

function checkABCPlus3TCPlusEFVAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;

		if(bodyweight>3 && bodyweight<10){
			$("#efv").modal('show');

		}else if(bodyweight>10 && bodyweight<14){
			var doseperunitone='60/30';
			var doseperunittwo='200';
			var totaldosageone='120/60';
			var totaldosagetwo='200';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunitone='60/30';
			var doseperunittwo='200';
			var totaldosageone='150/75';
			var totaldosagetwo='300';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunitone='60/30';
			var doseperunittwo='200';
			var totaldosageone='180/90';
			var totaldosagetwo='300';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25 && bodyweight<35){
			var doseperunitone='600/300';
			var doseperunittwo='200';
			var totaldosageone='600/300';
			var totaldosagetwo='400';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			
		}else if(bodyweight>35){
			var doseperunitone='600/300';
			var doseperunittwo='600';
			var totaldosageone='600/300';
			var totaldosagetwo='600';
			var frequencyone='OD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ABCPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

			}

		});
}

function checkTDFPlus3TCPlusEFVAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;
		
		if(bodyweight>34){
			var doseperunit='300/300/600';
			var totaldosage='300/300/600';
			var frequency='OD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else{
			$("#tdf3tcefv").modal('show');
			}
		});
}

function checkTDFPlus3TCPlusATVrAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;
		
		if(bodyweight>34){
			var doseperunitone='300/300';
			var doseperunittwo='300/100';
			var totaldosageone='300/300';
			var totaldosagetwo='300/100';
			var frequencyone='OD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=TDFPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else{
			$("#tdf3tcefv").modal('show');
			}
		});
}

function checkZDVPlus3TCPlusNVPAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;

		if(bodyweight>3 && bodyweight<6){
			var doseperunit='60/30/50';
			var totaldosage='60/30/50';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>6 && bodyweight<10){
			var doseperunit='60/30/50';
			var totaldosage='90/45/75';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>10 && bodyweight<14){
			var doseperunit='60/30/50';
			var totaldosage='120/60/100';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunit='60/30/50';
			var totaldosage='150/75/125';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunit='60/30/50';
			var totaldosage='180/90/150';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25){
			var doseperunit='300/150/200';
			var totaldosage='300/150/200';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			}
		});
}

function checkZDVPlus3TCPlusLPVrAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;

		if(bodyweight>3 && bodyweight<10){
			$("#zdv3tclpvr").modal('show');
		}else if(bodyweight>10 && bodyweight<14){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var totaldosageone='60/30';
			var totaldosagetwo='300/75';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var totaldosageone='150/75';
			var totaldosagetwo='200/50';
			var frequencyone='BD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var totaldosageone='180/90';
			var totaldosagetwo='200/50';
			var frequencyone='BD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25 && bodyweight<35){
			var doseperunitone='300/150';
			var doseperunittwo='100/25';
			var totaldosageone='300/150';
			var totaldosagetwo='300/75';
			var frequencyone='BD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			
		}else if(bodyweight>35){
			var doseperunitone='300/150';
			var doseperunittwo='200/50';
			var totaldosageone='300/150';
			var totaldosagetwo='400/100';
			var frequencyone='BD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

			}
		});
}
function checkZDVPlus3TCPlusLPVrPlusRTVAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;

		if(bodyweight>3 && bodyweight<10){
			$("#zdv3tclpvr").modal('show');
		}else if(bodyweight>10 && bodyweight<14){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var doseperunitrtv='100';
			var totaldosageone='60/30';
			var totaldosagetwo='300/75';
			var totaldosagertv='100';
			var frequencyone='BD';
			var frequencytwo='BD';
			var frequencyrtv='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPlusLPVrPrescription"
			var thirdurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitrtv+"&totaldose="+totaldosagertv+"&freq="+frequencyrtv+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
	        $( "#CccPrescriptionresult" ).load( secondurl);
			$( "#CccPrescriptionresult" ).load( thirdurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>14 && bodyweight<20){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var doseperunitrtv='100';
			var totaldosageone='150/75';
			var totaldosagetwo='200/50';
			var totaldosagertv='100';
			var frequencyone='BD';
			var frequencytwo='BD';
			var frequencyrtv='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPlusLPVrPrescription"
			var thirdurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitrtv+"&totaldose="+totaldosagertv+"&freq="+frequencyrtv+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
	        $( "#CccPrescriptionresult" ).load( secondurl);
			$( "#CccPrescriptionresult" ).load( thirdurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>20 && bodyweight<25){
			var doseperunitone='60/30';
			var doseperunittwo='100/25';
			var doseperunitrtv='100';
			var totaldosageone='180/90';
			var totaldosagetwo='200/50';
			var totaldosagertv='200';
			var frequencyone='BD';
			var frequencytwo='BD';
			var frequencyrtv='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPlusLPVrPrescription"
			var thirdurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitrtv+"&totaldose="+totaldosagertv+"&freq="+frequencyrtv+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
	        $( "#CccPrescriptionresult" ).load( secondurl);
			$( "#CccPrescriptionresult" ).load( thirdurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>25 && bodyweight<35){
			var doseperunitone='300/150';
			var doseperunittwo='100/25';
			var doseperunitrtv='100';
			var totaldosageone='300/150';
			var totaldosagetwo='300/75';
			var totaldosagertv='200';
			var frequencyone='BD';
			var frequencytwo='BD';
			var frequencyrtv='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPlusLPVrPrescription"
			var thirdurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitrtv+"&totaldose="+totaldosagertv+"&freq="+frequencyrtv+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
	        $( "#CccPrescriptionresult" ).load( secondurl);
			$( "#CccPrescriptionresult" ).load( thirdurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>35){
			var doseperunitone='300/150';
			var doseperunittwo='200/50';
			var doseperunitrtv='100';
			var totaldosageone='300/150';
			var totaldosagetwo='400/100';
			var totaldosagertv='200';
			var frequencyone='BD';
			var frequencytwo='BD';
			var frequencyrtv='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPlusLPVrPrescription"
			var thirdurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitrtv+"&totaldose="+totaldosagertv+"&freq="+frequencyrtv+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
	        $( "#CccPrescriptionresult" ).load( secondurl);
			$( "#CccPrescriptionresult" ).load( thirdurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			}
		});
}

function checkZDVPlusABCPlus3TCAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;

		if(bodyweight>3 && bodyweight<6){
			var doseperunit='60/60/30';
			var totaldosage='60/60/30';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
		}else if(bodyweight>6 && bodyweight<10){
			var doseperunit='60/60/30';
			var totaldosage='90/90/45';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>10 && bodyweight<14){
			var doseperunit='60/60/30';
			var totaldosage='120/120/60';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunit='60/60/30';
			var totaldosage='150/150/75';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunit='60/60/30';
			var totaldosage='180/180/90';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25){
			var doseperunit='300/300/150';
			var totaldosage='300/300/150';
			var frequency='BD';
			var durationofadministration='1';
			var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunit+"&totaldose="+totaldosage+"&freq="+frequency+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( url, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			}
		});
}

function checkZDVPlus3TCPlusEFVAgeAndWeight(obj){
	var objid = obj.id;
	var weightt = $.get("<?php echo $this->basePath()?>/pharmacy/search/getbodyweight?eid=<?php echo $this->eid;?>", function(weight){
		var bodyweight=weight;

		if(bodyweight>3 && bodyweight<10){
			var doseperunitone='60/30';
			var doseperunittwo='50';
			var totaldosageone='60/30';
			var totaldosagetwo='50';
			var frequencyone='BD';
			var frequencytwo='BD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			

		}else if(bodyweight>10 && bodyweight<14){
			var doseperunitone='60/30';
			var doseperunittwo='200';
			var totaldosageone='120/60';
			var totaldosagetwo='200';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>14 && bodyweight<20){
			var doseperunitone='60/30';
			var doseperunittwo='200';
			var totaldosageone='150/75';
			var totaldosagetwo='300';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>20 && bodyweight<25){
			var doseperunitone='60/30';
			var doseperunittwo='200';
			var totaldosageone='180/90';
			var totaldosagetwo='300';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

		}else if(bodyweight>25 && bodyweight<35){
			var doseperunitone='300/150';
			var doseperunittwo='200';
			var totaldosageone='300/150';
			var totaldosagetwo='400';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });
			
		}else if(bodyweight>35){
			var doseperunitone='300/150';
			var doseperunittwo='600';
			var totaldosageone='300/150';
			var totaldosagetwo='600';
			var frequencyone='BD';
			var frequencytwo='OD';
			var durationofadministration='1';
			var firsturl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunitone+"&totaldose="+totaldosageone+"&freq="+frequencyone+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function=ZDVPlus3TCPrescription"
			var secondurl = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?unitdose="+doseperunittwo+"&totaldose="+totaldosagetwo+"&freq="+frequencytwo+"&duration="+durationofadministration+"&plugin=CccPredefinedPrescription&function="+objid+"Prescription"
	        $( "#CccPrescriptionresult" ).load( firsturl);
			$( "#CccPrescriptionresult" ).load( secondurl, function() {
	            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
	        });

			}





		
		
		});
}

function submitcccPredefinedPrescription(obj){
    var objid = obj.id;
    var url = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined?plugin=CccPredefinedPrescription&function="+objid+"Prescription"
        $( "#CccPrescriptionresult" ).load( url, function() {
            self.location = "<?php echo $this->basePath()?>/pharmacy/prescription/cccpredefined";
        });
}
//-->
</script>