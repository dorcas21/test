function submitEmployeeAirtime(obj){
    var objid = obj.id;
    var url = "http://localhost/test/readcsv.php"

        $( "#airtime" ).load( url, function() {
        	alert("Airtime Sent To Employees");
            self.location = "http://localhost/test/index.php";
        	
        });
    
    
}
