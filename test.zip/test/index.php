<html>
<head>
<title>Employee Send Airtime</title>
<link rel="stylesheet"
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script
	src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="alert.js"></script>

</head>
<div class="container">
	<h2>Employee Airtime Details</h2>
	<table class="table table-bordered">
		<tr>
			<th>Employee Name</th>
			<th>Phone Number</th>
			<th>Amount(KES)</th>
		</tr>
					<?php $employees = array_map('str_getcsv', file('employee.csv'));?>
					
					<?php unset($employees[0]);?>
					<?php foreach ($employees as $employee) : ?>
				<tr>
			<td><?php echo $employee[0];?></td>
			<td><?php echo $employee[1];?></td>
			<td><?php echo $employee[2];?></td>
		</tr>
					<?php endforeach; ?>
		</table>
	<div class="container">
		<button class="btn btn-info btn-block" id="sendairtime"
			onclick="submitEmployeeAirtime(this)">Send Employees Airtime</button>
	</div>
	<div id="airtime"></div>
</div>

</html>

