<?php
require_once "AfricasTalkingGateway.php";

//Read the csv data into an array
$employees = array_map('str_getcsv', file('employee.csv'));
// Remove the csv headings
unset($employees[0]);
foreach ($employees as $employee) {
    // An array containing employee phone number and airtime amount
    $recipientArray = array(
        'amount' => 'KES ' . $employee[2],
        'phoneNumber' => '+' . $employee[1]
    
    );
    // function for passing the employee details to AfricasTalking gateway
    sendEmployeeAirtime($recipientArray);
}

function sendEmployeeAirtime($recipientArray)
{
    $username = "sandbox";
    $apiKey = "MyAppAPIKey";
    
    // This function receives airtime details for each employee and uses AfricasTalking API to send airtime..
    if ($recipientArray) {
        // Convert the array into json format
        $recipientStringFormat = json_encode($recipientArray);
        // Initialize the gateway
        $gateway = new AfricasTalkingGateway($username, $apiKey, "sandbox");
        try {
            $result = $gateway->sendAirtime($recipientStringFormat);
            echo $result->status;
            echo $result->amount;
            echo $result->phoneNumber;
            echo $result->discount;
            echo $result->requestId;
            echo 'here';
            // Error message is important when the status is not Success
            echo $result->errorMessage;
        } catch (AfricasTalkingGatewayException $e) {
            echo $e->getMessage();
        }
    }
    return $result;
}
