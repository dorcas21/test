<?php
require_once "AfricasTalkingGateway.php";

$employees = array_map('str_getcsv', file('employee.csv'));
unset($employees[0]);
foreach ($employees as $employee) {
    $recipientArray = array(
        'amount' => 'KES ' . $employee[2],
        'phoneNumber' => '+' . $employee[1]
        
    );
    sendEmployeeAirtime($recipientArray);
}

function sendEmployeeAirtime($recipientArray)
{
    $username = "sandbox";
    $apiKey = "MyAppAPIKey";
    
    // This function receives airtime details for each employee and uses AfricasTalking API to send airtime..
    if ($recipientArray) {
        $recipientStringFormat = json_encode($recipientArray);
        $gateway = new AfricasTalkingGateway($username, $apiKey, "sandbox");
        try {
            $result = $gateway->sendAirtime($recipientStringFormat);
            echo $result->status;
            echo $result->amount;
            echo $result->phoneNumber;
            echo $result->discount;
            echo $result->requestId;
            
            //Error message is important when the status is not Success
            echo $result->errorMessage;
            
        }
        catch(AfricasTalkingGatewayException $e){
        echo $e->getMessage();
        }
        
    }
    return $result;
}
